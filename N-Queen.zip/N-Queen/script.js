let score = 0;
let queens = [];

function startGame(size) {
    const board = document.getElementById('gameBoard');
    board.style.setProperty('--grid-size', size);
    board.innerHTML = '';
    score = 0;
    queens = [];
    updateScore();

    for (let row = 0; row < size; row++) {
        for (let col = 0; col < size; col++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.dataset.row = row;
            cell.dataset.col = col;
            cell.addEventListener('click', () => placeQueen(row, col, size));
            board.appendChild(cell);
        }
    }
}

function placeQueen(row, col, size) {
    const existingQueenIndex = queens.findIndex(([qRow, qCol]) => qRow === row && qCol === col);
    const cell = document.querySelector(`.cell[data-row='${row}'][data-col='${col}']`);

    if (existingQueenIndex !== -1) {
        queens.splice(existingQueenIndex, 1);
        cell.classList.remove('queen');
        score = Math.max(0, score - 3);  // Prevent negative score
        updateScore();
        return;
    }

    if (!isSafe(row, col)) {
        Swal.fire({
            title: 'Incorrect Placement!',
            text: 'You can change your past points and try again.',
            icon: 'error',  // Red error icon
            confirmButtonText: 'Try Again',
            confirmButtonColor: '#FF4136',  // Red button color
            background: '#fff0f0',  // Light red background
            iconColor: '#FF4136',  // Red icon
            customClass: {
                popup: 'smaller-rectangular-alert',  // Custom class for rectangular popup
                title: 'font-semibold text-xl',  // Adjusted text size for title
                text: 'text-base',  // Adjusted text size for message
                confirmButton: 'px-6 py-2 rounded-lg text-white'  // Adjust button padding
            },
            willOpen: () => {
                const popup = Swal.getPopup();
                popup.style.width = '400px';  // Custom width for rectangular shape
                popup.style.borderRadius = '10px';  // Make it rectangular with rounded corners
            }
        });

        score = Math.max(0, score - 3);  // Prevent score going below zero
        updateScore();
        return;
    }

    cell.classList.add('queen');
    queens.push([row, col]);

    score += 3;  // Increase score on correct placement
    updateScore();

    if (queens.length === size) {
        Swal.fire({
            title: 'Congratulations!',
            text: 'You solved the puzzle! 🎉',
            icon: 'success',  // Green success icon
            confirmButtonText: 'Start New Game',
            confirmButtonColor: '#4CAF50',  // Green button color
            background: '#e8f5e9',  // Light green background
            iconColor: '#4CAF50',  // Green icon
            customClass: {
                popup: 'smaller-rectangular-alert',  // Custom class for rectangular popup
                title: 'font-semibold text-xl',  // Adjusted text size for title
                text: 'text-base',  // Adjusted text size for message
                confirmButton: 'px-6 py-2 rounded-lg text-white'  // Adjust button padding
            },
            willOpen: () => {
                const popup = Swal.getPopup();
                popup.style.width = '400px';  // Custom width for rectangular shape
                popup.style.borderRadius = '10px';  // Make it rectangular with rounded corners
            }
        }).then(() => {
            startGame(size);  // Start a new game after the user confirms
        });
    }
}



function updateScore() {
    document.getElementById('score').textContent = score;  // Ensure score display is updated properly
}


function isSafe(row, col) {
    for (const [qRow, qCol] of queens) {
        if (qRow === row || qCol === col || Math.abs(qRow - row) === Math.abs(qCol - col)) {
            return false;
        }
    }
    return true;
}

function updateScore()
 {
    document.getElementById('score').textContent = score;
    if (score <= -1) {
        alert('Game Over! You ran out of points.');
        startGame(queens.length);
    }
}





startGame(4);
